FyD-Template_Files
=========

The development files for the Familiar yet Different texture pack.

##[Feed the Beast forum post] (http://forum.feed-the-beast.com/threads/16x-familiar-yet-different-ftb-wip.633/)
***
##Usage

Anyone can use the texture/templates in this folder to add support for a mod not in the FTB packs.
***
##Folder Info

This is only the template textures folder, for the other folders please see [1.6.X](https://github.com/Morton00000/FyD-1.6.X), [1.5.2](https://github.com/Morton00000/FyD-1.5.1), or [1.4.7](https://github.com/Morton00000/FyD-1.4.7). 
***
##Purpose

The purpose of this is to let people know how I do things.
***
##Other

If you did actually read all of this make a post about it and leave some feed-back on the forum post.

It is okay to correct my grammar/spelling just don't get overbearing.
